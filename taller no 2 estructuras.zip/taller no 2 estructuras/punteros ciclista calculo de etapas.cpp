#include <stdio.h>
struct recorrer{
	int hora;
	int minutos;
	int segundos;
}ciclistas[3], *p_ciclistas=ciclistas;

int main (){
	
	for(int i=0;i<3;i++){
		
		printf("Ingrese la hora del ciclista # %d: ", i+1);
		scanf("%d",&(p_ciclistas+i)->hora);
		printf("Ingrese los minutos del ciclista # %d: ", i+1);
		scanf("%d", &(p_ciclistas+i)->minutos);
		printf("Ingrese horas del ciclista # %d: ", i+1);
		scanf("%d",&(p_ciclistas+i)->segundos);
		printf("\n");
	}
	
	int hor=0,min=0,seg=0;
	
	
	for(int i=0;i<3;i++){
		seg+=(p_ciclistas+i)->segundos;
		min+=(p_ciclistas+i)->minutos;
		hor+=(p_ciclistas+i)->hora;
		if (seg>=60){
			min+=1;
			seg-=60;
		}
		if(min>=60){
			hor+=1;
			min-=60;
		}
	}
	printf("El tiempo fue de:  %d Horas %d Minutos %d Segundos",hor,min,seg);
	
	return 0;
}


	
