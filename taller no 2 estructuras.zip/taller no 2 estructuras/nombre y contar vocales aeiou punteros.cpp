#include<stdio.h>



int main(){
	char nombre[30];
	char *p_nom;
	int cont=0; 
	
	printf("Digite su nombre: ");
	fgets(nombre,30,stdin);
	
	p_nom = &nombre[0];
	
	while(*p_nom){
		switch(*p_nom){
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':	cont++;
		}
		p_nom++;
		
	}
	
	printf("El numero de vocales son %d ", cont);
	
	
	return 0;
	
	
}


