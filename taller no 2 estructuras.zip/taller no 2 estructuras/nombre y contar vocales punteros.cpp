#include<stdio.h>
#include<string.h>



int main(){
	char nombre[50];
	char *p_nomA,*p_nomE,*p_nomI,*p_nomO,*p_nomU;
	int contA=0,contE=0,contI=0,contO=0,contU=0; 
	
	printf("Digite su nombre: ");
	fgets(nombre,50,stdin);
	fflush(stdin);
	
	p_nomA = &nombre[0];
	p_nomE = &nombre[0];
	p_nomI = &nombre[0];
	p_nomO = &nombre[0];
	p_nomU = &nombre[0];
	
	while(*p_nomA){
		
		switch(*p_nomA){
		case 'a':{
			contA++;
			
		}
		}
		p_nomA++;
		
	}
	
	while(*p_nomE){
		
		switch(*p_nomE){
		case 'e':{
			contE++;
		}
		}
		p_nomE++;
		
	}
	
	
	while(*p_nomI){
		
		switch(*p_nomI){
		case 'i':{
			contI++;
		}
		}
		p_nomI++;
	}
	
	while(*p_nomO){
		
		switch(*p_nomO){
		case 'o':{
			contO++;
		}
		}
		p_nomO++;
	}
	
	while(*p_nomU){
		
		switch(*p_nomU){
		case 'u':{
			contU++;
			
			
		}	
		}
		p_nomU++;
	}
	
	
	printf("El numero de veces que aparecer la vocal A es %d\n", contA);
	printf("El numero de veces que aparecer la vocal E es %d\n", contE);
	printf("El numero de veces que aparecer la vocal I es %d\n", contI);
	printf("El numero de veces que aparecer la vocal O es %d\n", contO);
	printf("El numero de veces que aparecer la vocal U es %d\n", contU);
	
	
	return 0;
	
	
	
}







