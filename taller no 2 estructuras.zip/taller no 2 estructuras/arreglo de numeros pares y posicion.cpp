#include<stdio.h>

int main(){
	int x[10]={20,30,40,55,60,65,79,46,87,38},i, *p_x;
	
	p_x = &x[0];  
	
	for(i=0;i<10;i++)
	{
		*(p_x+i) = x[i]; 
		
	}
	
	for(i=0;i<10;i++)
	{
	
	if(*(p_x+i)%2==0){ 
		printf("El numero %d es par\n",*(p_x+i));
		printf("La posicion de memoria es: %p\n",(&p_x+i)); 
	}
	}
	
	
	
	
	return 0;
}
