#include<stdio.h>

int main(){
	
	
	int x[100],i,n,*p_x;
	
	printf("Ingrese la cantidad de numeros: ", &n);
	scanf("%d",&n);
	
	p_x = &x[0];  
	
	for(i=0;i<n;i++)
	{
		printf("Por favor digitar los numeros: ", *(p_x+i));
		scanf("%d",(p_x+i));
		//*(p_x+i) = x[i]; 
		
	}
	int menor;
	
	for(i=0;i<n;i++)
	{
		
		if(menor > *(p_x+i)){ 
			
			menor = *(p_x+i);

		}
	}
	
	printf("\nEl menor elemento es el numero %d \n",menor);
	
	
	
	
	return 0;
}
